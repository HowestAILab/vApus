Dependencies: 
* JRE8 64-bit or more recent (default-jre-headless package for Debian)
* optional: gawk, dmidecode