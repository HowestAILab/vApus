It is possible that the agent fails the first time. This because of driver initialisation. This agent will not work (correctly) for VMs.           
Dependencies:
### Linux
* root privileges
* JRE6 64-bit or more recent (default-jre-headless package for Debian)
* msr-tools (Debian package in the default repositories)

### Windows
* Administrator privileges
* JRE6 64-bit or more recent
* .Net 4.0 or newer