﻿Dependencies:
* Administrator privileges
* .Net Framework 4.5 or newer